﻿if((Get-Item "HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired" -ErrorAction SilentlyContinue).Property) {
  write-output "reboot pending"
}
else {write-output "No reboot required"}