﻿Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine -Force
Install-PackageProvider -Name NuGet -Force
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
Install-Module PSWindowsUpdate -Force

Import-Module PSWindowsUpdate -Force

Get-WindowsUpdate | Out-File C:\Pending-Windows-Updates.txt

Install-WindowsUpdate -AcceptAll -ForceInstall -RecurseCycle:'2' -IgnoreReboot | Out-File c:/update-installation.txt