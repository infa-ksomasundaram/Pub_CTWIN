﻿Start-Process PowerShell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File 'C:/temp/scripts/CTWin_Scripts/Windows-Update.ps1'" -Verb RunAs -Wait
