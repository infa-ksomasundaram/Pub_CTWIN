﻿# Define the log file path
$LogFilePath = "C:\temp\UpdateLog.txt"

# Function to log messages to a file
function LogMessage($message) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "$timestamp - $message"
    $logEntry | Out-File -FilePath $LogFilePath -Append -Encoding UTF8
}

# Check if the script is running as an administrator
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    $message = "This script needs to be run as an administrator."
    LogMessage $message
    Write-Host $message
    exit
}

# Initialize a log message
$LogMessage = "Updates-Installing"

# Define the update session
$Session = New-Object -ComObject Microsoft.Update.Session

# Define the update searcher
$Searcher = $Session.CreateUpdateSearcher()

# Search for available updates
$Updates = $Searcher.Search("IsInstalled=0")

# Check if there are pending updates
if ($Updates.Updates.Count -gt 0) {
    $LogMessage = "Updates found. Downloading and installing updates forcefully.`r`n"

    # Download and install updates forcefully
    $Installer = $Session.CreateUpdateInstaller()
    $Installer.Updates = $Updates.Updates
    $InstallationResult = $Installer.Install()

    # Check if updates were successfully installed
    if ($InstallationResult.ResultCode -eq 2) {
        $LogMessage += "Updates installed successfully. A reboot may be required.`r`n"
    } else {
        $LogMessage += "Update installation failed with result code $($InstallationResult.ResultCode).`r`n"
    }
} else {
    $LogMessage = "No pending updates found.`r`n"
}

# Log the update process
LogMessage $LogMessage

# Display the log message
Write-Host $LogMessage
