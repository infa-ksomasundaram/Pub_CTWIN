﻿# Check for Windows Updates
$Session = New-Object -ComObject Microsoft.Update.Session
$Searcher = $Session.CreateUpdateSearcher()
$Updates = $Searcher.Search("IsInstalled=0")

# If there are updates available, download and install them
if ($Updates.Updates.Count -gt 0) {
    Write-Host "Downloading and installing updates..."
    $Downloader = $Session.CreateUpdateDownloader()
    $Downloader.Updates = $Updates.Updates
    $Downloader.Download()

    $Installer = New-Object -ComObject Microsoft.Update.Installer
    $Installer.Updates = $Updates.Updates
    $Result = $Installer.Install()
    
    # Check the installation result
    if ($Result.ResultCode -eq 2) {
        Write-Host "Installation successful. Reboot is required to complete the installation."
    } else {
        Write-Host "Installation failed with result code $($Result.ResultCode)."
    }
} else {
    Write-Host "No updates are available."
}
