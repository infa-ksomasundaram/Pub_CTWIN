﻿# Import the PSWindowsUpdate module
Import-Module PSWindowsUpdate

# Check for available updates
$updates = Get-WindowsUpdate -AcceptAll

if ($updates.Count -eq 0) {
    Write-Host "No updates are available."
} else {
    # Install all available updates and automatically reboot if needed
    Install-WindowsUpdate -AcceptAll -ForceInstall -IgnoreReboot
}
