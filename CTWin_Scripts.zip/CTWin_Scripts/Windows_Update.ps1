﻿# Run Windows Update
Write-Host "Running Windows Update..."
Install-WindowsUpdate -AcceptAll -AutoReboot
Write-Host "Windows Update completed."
