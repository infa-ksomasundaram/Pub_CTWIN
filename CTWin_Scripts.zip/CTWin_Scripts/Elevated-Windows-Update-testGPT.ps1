﻿Start-Process PowerShell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File 'C:/temp/scripts/CTWin_Scripts/Windows-Update-testGPT1.ps1'" -Verb RunAs
