﻿Start-Process PowerShell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File 'C:/temp/scripts/CTWin_Scripts/Windowsupdate.ps1'" -Verb RunAs -Wait
