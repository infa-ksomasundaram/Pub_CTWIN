﻿cd "C:\CT-Agents\Filebeat\filebeat-8.10.3-windows-x86_64\" 

.\install-service-filebeat.ps1