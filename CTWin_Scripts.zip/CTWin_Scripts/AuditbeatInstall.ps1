﻿cd "C:\CT-Agents\Auditbeat\auditbeat-8.10.3-windows-x86_64\" 

.\install-service-auditbeat.ps1