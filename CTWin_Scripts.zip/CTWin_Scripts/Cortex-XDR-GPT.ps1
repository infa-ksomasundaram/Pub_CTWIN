﻿$msiPath = "C:/temp/CT-Agents/CT-Agent/Cortex-XDR/infa-commercial-cortex-xdr-windows-772_x64.msi"

if (Test-Path $msiPath) {
    Write-Host "Installing $msiPath as administrator..."
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$msiPath`"" -Verb RunAs -Wait
    Write-Host "Installation complete."
} else {
    Write-Host "The specified MSI file does not exist."
}