﻿New-Item -Type Directory -Path 'c:/' -Name temp
New-Item -Type Directory -Path 'c:/temp/' -Name scripts
New-Item -Type Directory -Path 'c:/temp/' -Name CT-Agents 